#ifndef _TIME_PING_H
#define _TIME_PING_H
#include "total_wifi.h"
#include "usart3.h"     //������Ҫ��ͷ�ļ�
#define PING_TIME_EN  1

#if (PING_TIME_EN==1)
#define PING_TIME  TIM1
#define PING_TIME_RCC  RCC_APB2Periph_TIM1
#define PING_TIME_IRQn  TIM1_UP_IRQn
#define PING_TIME_IRQHandler TIM1_UP_IRQHandler

#elif (PING_TIME_EN==2)
#define PING_TIME  TIM2
#define PING_TIME_RCC  RCC_APB1Periph_TIM2			
#define PING_TIME_IRQn  TIM2_IRQn
#define PING_TIME_IRQHandler TIM2_IRQHandler
#elif (PING_TIME_EN==3)
#define PING_TIME  TIM3
#define PING_TIME_RCC  RCC_APB1Periph_TIM3		
#define PING_TIME_IRQn  TIM3_IRQn
#define PING_TIME_IRQHandler TIM3_IRQHandler
#endif
void PING_TIM_ENABLE_1S(void);
void PingREQ(void);
extern u32 time_1s;
extern u8 Timed_upload;//���ڶ�ʱ�ϴ��ı���
#endif
